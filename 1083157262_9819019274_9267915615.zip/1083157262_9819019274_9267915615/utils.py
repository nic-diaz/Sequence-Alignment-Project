
ALPHA =     {('A', 'A'): 0, ('A', 'C'): 110, ('A','G'): 48, ('A', 'T'): 94,
             ('C', 'A'): 110, ('C','C'): 0, ('C','G'): 118, ('C','T'): 48,
             ('G', 'A'): 48, ('G','C'): 118, ('G','G'): 0, ('G', 'T'): 110,
             ('T', 'A'): 94, ('T','C'): 48, ('T', 'G'): 110, ('T','T'): 0}

DELTA = 30

def generate_strings(base_strings):
    """
    Generates cumulative strings from base words and insert indicies 
    """
    strings = []
    i = 0
    j = 0

    for word in base_strings:
        cumulative_string = word

        for num in base_strings[word]:
            cumulative_string = cumulative_string[:num+1] + cumulative_string + \
                                cumulative_string[num+1:]

        strings.append(cumulative_string)
        
        # Validating the final string lengths
        k = len(base_strings[word])
        if (2**k)*len(word) != len(cumulative_string):
            print("ERROR: GENERATING FINAL STRINGS FROM INPUT FILE")
            quit()

    return strings


def parse_file(filename):
    """
    Returns a dictionary with base strings and indicies for cumulative string creation
    For example: {'ACTG': [3, 6, 1, 1], 'TACG': [1, 2, 9, 2]} 
    """
    base_strings = {}
    base_str = ''
    
    with open(filename) as file:
        for line in file:
            line = line.rstrip()

            if line.isdigit() == True:
                base_strings[base_str].append(int(line))
            else:
                base_strings[line] = [] 
                base_str = line
    
    return base_strings

def find_solution(s1, s2, alignment):
    '''
    Uses alignment to generate the final strings
    '''
    final_s1, final_s2 = "", ""
    alignment += [[len(s1), len(s2)]]

    for k in range(len(alignment)-1):

        x_k, y_k = alignment[k]

        if [x_k + 1, y_k + 1] == alignment[k+1]:
            final_s1 += s1[x_k]
            final_s2 += s2[y_k]
            
        elif [x_k + 1, y_k] == alignment[k+1]:
            final_s1 += s1[x_k]
            final_s2 += "_"
        else:
            final_s1 += "_"
            final_s2 += s2[y_k]

    return final_s1, final_s2

def validate(s1, s2):
    '''
    Helper function to check the final strings optimal costs
    '''
    total_costs = 0

    for i in range(len(s1)):
        total_costs += DELTA if (s1[i] == "_" or s2[i] == "_") else ALPHA[(s1[i], s2[i])]
    return total_costs

def main():

    base_strings = parse_file('input.txt')
    print(f"Generated dictionary: {base_strings}\n")

    strings = generate_strings(base_strings)
    print(f"Generated cumulative strings: {strings}\n")

if __name__ == "__main__":
   main()