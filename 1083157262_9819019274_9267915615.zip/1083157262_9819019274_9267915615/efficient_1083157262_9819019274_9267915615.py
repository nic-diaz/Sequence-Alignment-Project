from basic_1083157262_9819019274_9267915615 import basic
import sys
import numpy as np
from utils import parse_file, generate_strings, find_solution, validate, ALPHA, DELTA
import itertools
from time import perf_counter
import tracemalloc

P = []

def space_efficient_alignment(s1,s2):
  m = len(s1) + 1
  n = len(s2) + 1

  B = np.zeros((m, 2))

  B[:, 0] = np.arange(m) * DELTA

  for j in range(1,n):
    B[0,1] = j * DELTA

    for i in range(1,m):
        B[i, 1] = min(ALPHA[(s1[i-1], s2[j-1])] + B[i-1,0], DELTA + B[i-1, 1], DELTA + B[i, 0])

    B[:,0] = B[:,1]

  return B[:,1]

  
def efficient(s1, s2, s1_offset=0, s2_offset=0):
  m = len(s1)
  n = len(s2)

  if m <= 2 or n <= 2:
    _, opt_alignment, _ = basic(s1, s2)
    P.extend([[p1 + s1_offset, p2 + s2_offset] for p1, p2 in opt_alignment])
    return P
  
  F = space_efficient_alignment(s1, s2[:n//2])
  G = space_efficient_alignment(s1[::-1], s2[n//2:][::-1])

  q_val = 100000000000
  q = 0

  for i in range(len(F)):
    opt_q = F[i] + G[m-i]
    if opt_q <= q_val:
      q_val = opt_q
      q = i

  P.append([s1_offset + q, s2_offset + (n//2)])

  efficient(s1[:q], s2[:n//2], s1_offset, s2_offset)
  
  s1_offset += q
  s2_offset += (n//2)

  efficient(s1[q:], s2[(n//2):], s1_offset, s2_offset)
  
  return P

if __name__ == "__main__":
  base_strings = parse_file(sys.argv[1])
  strings = generate_strings(base_strings)
  s1, s2 = strings
  str_len = len(s1) + len(s2)

  tracemalloc.start()
  start = perf_counter()
  alignments = efficient(s1, s2)
  end = perf_counter()

  total_time = end-start
  total_mem = tracemalloc.get_traced_memory()[0] / 1000
  
  alignments.sort()
  alignments = list(k for k,_ in itertools.groupby(alignments))
  
  final_s1, final_s2 = find_solution(s1, s2, alignments)
  opt = validate(final_s1, final_s2)

  with open('output.txt','w') as f:
    f.write(final_s1[:50] + " " + final_s1[-50:] + "\n")
    f.write(final_s2[:50] + " " + final_s2[-50:] + "\n")
    f.write(str(opt) + "\n")
    f.write(str(total_time) + "\n")
    f.write(str(total_mem))

  # for plots
  # with open('test.txt', 'a') as fw:
  #       fw.write(f'efficient,{str_len},{total_time},{total_mem}\n')