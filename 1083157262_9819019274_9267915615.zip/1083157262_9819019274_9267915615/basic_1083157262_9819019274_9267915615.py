import numpy as np
import sys
from utils import parse_file, generate_strings, validate, ALPHA, DELTA, find_solution
from time import perf_counter
import tracemalloc


def alignment(A, s1, s2, i, j):
    '''
    Finds optimal alignment after tracing back through A
    '''
    path = []
    while True:
        if i + j == 0: return path
        if i == 0: return path + [[i, k] for k in range(j-1,-1,-1)]
        if j == 0: return path + [[k, j] for k in range(i-1,-1,-1)]
    
        mismatch = ALPHA[(s1[i-1], s2[j-1])] + A[i-1,j-1]
        gap_left = DELTA + A[i-1, j]
        gap_up = DELTA + A[i, j-1]

        min_idx = np.argmin([mismatch, gap_up, gap_left])

        if min_idx == 0: i, j = i - 1, j - 1
        elif min_idx == 1: j -= 1
        else: i -= 1

        path += [[i,j]]

def basic(s1, s2):
    '''
    Calculates the A matrix containing the optimal costs from (0,0) to each (i,j) 
    '''
    
    m = len(s1) + 1
    n = len(s2) + 1

    A = np.zeros((m, n))

    A[:, 0] = np.arange(m) * DELTA
    A[0, :] = np.arange(n) * DELTA

    for i in range(1,m):
        for j in range(1,n):
            A[i, j] = min(ALPHA[(s1[i-1], s2[j-1])] + A[i-1,j-1], DELTA + A[i-1, j], DELTA + A[i, j-1])

    opt_alignment = alignment(A, s1, s2, len(s1), len(s2))

    return A, opt_alignment[::-1], A[m-1,n-1]

if __name__ == "__main__":
    base_strings = parse_file(sys.argv[1])
    strings = generate_strings(base_strings)
    s1, s2 = strings
    str_len = len(s1) + len(s2)

    tracemalloc.start()

    start = perf_counter()
    A, opt_alignment, opt = basic(s1, s2)
    end = perf_counter()

    total_time = end-start
    total_mem = tracemalloc.get_traced_memory()[0] / 1000

    final_s1, final_s2 = find_solution(s1, s2, opt_alignment)

    with open('output.txt','w') as f:
        f.write(final_s1[:50] + " " + final_s1[-50:] + "\n")
        f.write(final_s2[:50] + " " + final_s2[-50:] + "\n")
        f.write(str(opt) + "\n")
        f.write(str(total_time) + "\n")
        f.write(str(total_mem))
    
    # for plots
    # with open('test.txt', 'a') as fw:
    #     fw.write(f'basic,{str_len},{total_time},{total_mem}\n')